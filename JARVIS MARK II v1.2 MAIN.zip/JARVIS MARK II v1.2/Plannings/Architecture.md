# System Architecture

## 1. High-Level Architecture
JARVIS MARK II (v1.2) utilizes a modular, event-driven architecture designed for low-latency asynchronous processing. The system is divided into four primary domains: Audio Engine, Brain Core, Local OS Runner, and Memory Store.

*Note: To accelerate development and leverage proven architectures, selected modules and agents (including specific agent workflows and tool-calling scripts) will be extracted, adapted, and refactored from the Open JARVIS repository and natively integrated into our v1.2 structure.*

## 2. Sequence Diagram: Data Flow

```mermaid
sequenceDiagram
    participant U as User
    participant A as Audio Engine (STT/TTS)
    participant B as Brain Core (ReAct)
    participant M as Memory Store
    participant O as Local OS Runner
    
    U->>A: Voice Input ("JARVIS, open Spotify")
    A->>B: Transcribed Text
    B->>M: Retrieve Context/History
    M-->>B: Short-term memory & preferences
    B->>B: Analyze Intent & Plan Action
    B->>O: Dispatch Tool Call (launch_app: spotify)
    O-->>B: Execution Result (Success)
    B->>A: Generate Response Text ("Opening Spotify, sir.")
    A->>U: Audio Output (TTS)
```

## 3. Subsystem Breakdowns

### 3.1 Audio Engine
- **Wake-Word Listener:** Lightweight process constantly monitoring microphone input.
- **STT Module:** Transcribes user audio into text upon wake-word activation or manual trigger.
- **TTS Module:** Synthesizes the Brain Core's text responses into audio.
- **Audio Manager:** Handles microphone stream, speaker output, and interruption logic (barge-in).

### 3.2 Brain Core
- **Intent Router:** Fast, lightweight classifier to route queries (e.g., simple OS command vs. complex reasoning).
- **Reasoning Engine:** Implements the ReAct (Reasoning + Acting) loop. Determines which tools to call, processes results, and formulates the final response.
- **LLM Client:** Interfaces with the underlying Large Language Model (local or cloud-based) for natural language understanding and generation.

### 3.3 Local OS Runner (with MCP Support)
- **Tool Executor:** Runs local OS commands. Includes support for **Model Context Protocol (MCP)** tool wrappers alongside our custom `BaseTool` schema, enabling seamless integration with OpenJarvis tools.
- **API Wrappers:** Python wrappers around OS APIs (e.g., PyAutoGUI, Windows APIs) for controlling media, applications, and gathering system stats.
- **Sandboxing:** Ensures all commands are executed within the boundaries of the standard user. Maintains strict user-level privilege execution (NO root/admin elevation).

### 3.4 Memory Store
- **Short-Term Context:** Fast, in-memory store for the current conversation turn and active tasks.
- **Long-Term Storage:** Persistent database for user preferences, custom commands, and historical data, incorporating semantic local memory indexing strategies (SQLite + ChromaDB / RAG).

### 3.5 Specialized Agents (OpenJarvis Adaptations)
- **Morning Digest Agent:** Scheduled background briefing engine providing email, system health, and local news summaries via TTS.
- **Deep Research Agent:** Multi-hop document and web research tool with citation indexing.
- **Code Assistant Agent:** Secure local file editing and non-admin command execution runner.
- **Continuous Operative / Monitor:** Background task monitoring loop running inside the async scheduler.

## 4. Security Model
- **Principle of Least Privilege:** The JARVIS process must only be run as a standard user. It is explicitly forbidden from requesting or operating with Administrator/UAC elevated privileges.
- **Command Validation:** The Local OS Runner uses predefined, strict templates for OS commands. Unvalidated execution of arbitrary strings (e.g., `os.system()` with raw LLM output) is blocked.
- **Network Boundaries:** Communication with external cloud LLMs must be encrypted (HTTPS/WSS) and exclude sensitive personal files unless explicitly permitted by the user.

## Implementation Status (V1.2)

**Status**: COMPLETE — All subsystems implemented and tested.

### Subsystem Map (as implemented)

| Subsystem | Module | Status |
|---|---|---|
| Audio Engine (STT) | `audio/stt.py` | COMPLETE — VAD + faster-whisper |
| Audio Engine (TTS) | `audio/tts.py` | COMPLETE — edge-tts + pygame |
| Brain Core (ReAct) | `core/brain.py` | COMPLETE — 15-tool registry, confirmation gate, memory injection |
| LLM Provider | `core/llm.py` | COMPLETE — DeepSeek via AsyncOpenAI |
| Memory (SQLite) | `core/memory.py` | COMPLETE — preferences + aliases |
| Memory (ChromaDB) | `core/memory.py` | COMPLETE — semantic facts, local persistence |
| OS Tools | `tools/system_tools.py` | COMPLETE — 8 tools, user-home restricted |
| Memory Tools | `tools/memory_tools.py` | COMPLETE — 7 tools incl. deep_research |
| Code Assistant | `agents/code_assistant.py` | COMPLETE — secure file editing |
| Continuous Operative | `agents/operative.py` | COMPLETE — 30s background monitor |
| Morning Digest | `agents/morning_digest.py` | COMPLETE — scheduled TTS briefing |
| Deep Research | `agents/deep_research.py` | COMPLETE — ChromaDB semantic research |
| HUD Overlay | `ui/hud.py` | COMPLETE — tkinter, daemon thread |
| State Machine | `main.py` | COMPLETE — wake/awake/idle loop |

### Final Architecture Flow (implemented)
```
User Voice
  ↓ VAD+Whisper (audio/stt.py)
Brain Core (core/brain.py)
  ↓ Memory Context Retrieval (core/memory.py → ChromaDB)
  ↓ LLM ReAct Loop (core/llm.py → DeepSeek API)
  ↓ Tool Dispatch (tools/system_tools.py + tools/memory_tools.py)
  ↓ Agent Delegation (agents/)
  ↓ Confirmation Gate (destructive actions)
TTS Response (audio/tts.py → edge-tts)
  ↓ HUD State Update (ui/hud.py ← utils/audio_utils.py)
```

**Last Verified**: 2026-09-11
