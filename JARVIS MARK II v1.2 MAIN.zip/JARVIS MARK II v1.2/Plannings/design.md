# UX and Persona Design

## 1. Voice UX Specifications
- **Wake-Word Detection:** Must be highly resilient to background noise. False positives should be minimized to avoid unintended recordings.
- **Audio Feedback Chimes:**
  - *Wake Chime:* A subtle, crisp, high-tech ping indicating JARVIS is listening.
  - *Success Chime:* A soft confirmation tone for background tasks completed without needing a verbal response.
  - *Error Chime:* A distinct, low-pitch tone indicating a failure or misunderstanding.
- **Speech Interruption (Barge-in):** When JARVIS is speaking, any detection of the wake-word or significant user speech must immediately stop the TTS audio buffer and transition the system back to the 'Listening' state.

## 2. Visual HUD / Overlay Interface Concept
- **Design Language:** Minimalist, futuristic, non-intrusive. Thin lines, subtle glows, monochromatic or dual-tone (e.g., stark white and subtle cyan).
- **State Indicators:**
  - **Idle:** A dim, slow-pulsing geometric shape in the corner of the screen.
  - **Listening:** The shape expands and reacts to microphone audio waveforms.
  - **Processing:** A fast-spinning or loading animation indicating network/LLM activity.
  - **Speaking:** Modulated pulsing synced to the amplitude of the TTS output.
- **Placement:** Draggable or fixed to a corner (e.g., bottom-right or top-center), ensuring it does not obscure primary user workspace elements.

## 3. Voice Persona & Speech Guidelines
- **Core Traits:** Professional, witty, polite, highly efficient, and slightly dry.
- **Tone:** Calm, collected, and deferential, typically addressing the user as "Sir" or "Ma'am" (configurable).
- **Brevity:** Responses must be concise. JARVIS should prioritize executing the action over explaining it.
  - *Bad:* "I have successfully processed your request and am now opening the Spotify application for you."
  - *Good:* "Opening Spotify, sir."
- **Humor:** Dry wit is acceptable in conversational queries, but should never interfere with the clarity of task execution.
- **Error Handling Speech:** Apologetic but actionable. (e.g., "I'm afraid I cannot find that file. Would you like me to broaden the search?")

## Implementation Status (Phase 4)
- **Status**: COMPLETE
- **Visual HUD**: Implemented via `ui/hud.py` using `tkinter`. Features a transparent background, color-coded state indicators (Idle=Grey, Listening=Cyan, Processing=Orange, Speaking=Blue), and is fully draggable by the user. Runs independently of the async event loop.
- **Voice UX**: Wake chime and TTS are fully operational in `audio/tts.py`. Barge-in event is fully wired via `AudioState`.
- **Last Verified**: 2026-09-11

