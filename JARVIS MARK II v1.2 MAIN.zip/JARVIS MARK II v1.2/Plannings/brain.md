# Brain Core & Reasoning Engine

## 1. Reasoning Engine Structure
The Brain Core operates on an asynchronous ReAct (Reasoning + Acting) loop. To ensure robustness and efficiency, specific agent workflows, prompt patterns, and tool-calling scripts will be extracted from the Open JARVIS repository, adapted, and refactored to fit natively into our architecture (e.g., Code Assistant Agent, Deep Research Agent, and Morning Digest Agent).

1. **Input Reception:** Receives transcribed text from the Audio Engine.
2. **Context Injection:** Retrieves short-term history and relevant long-term memories via semantic indexing (ChromaDB/RAG).
3. **Reasoning (Thought):** The LLM analyzes the request and determines if a tool needs to be called or if a direct response is sufficient.
4. **Action (Act):** If a tool is required, the LLM outputs a structured JSON tool call. The engine suspends the LLM, executes the local tool (supporting both native `BaseTool` and `MCP` wrappers), and captures the output.
5. **Observation:** The tool output is fed back into the LLM.
6. **Resolution:** The LLM generates the final textual response to be synthesized by the TTS module.

## 2. LLM Routing
To optimize for latency and cost, a two-tier routing system is utilized:
- **Fast Intent Classifier:** A very small, fast local model or rule-based router that checks if the request is a simple, mapped command (e.g., "Pause music", "What time is it?"). If yes, it bypasses the heavy LLM and directly triggers the tool and a canned response.
- **Cloud LLM (DeepSeek-Chat / GPT-4o):** For complex requests requiring logic, multi-step planning, or general knowledge, the query is dispatched to the high-capability cloud model.

## 3. Tool Registration & Execution Matrix
Tools are strictly defined using JSON schemas. The Local OS Runner maps these schemas to Python functions. The execution matrix supports both custom native tools and dynamically loaded Model Context Protocol (MCP) wrappers.

| Tool Name | Description | Required Parameters | Permissions |
| :--- | :--- | :--- | :--- |
| `launch_application` | Opens a user-level program. | `app_name` (string) | User execution |
| `media_control` | Controls active media playback. | `command` (enum: play, pause, next, prev, vol_up, vol_down) | User media APIs |
| `get_system_status` | Retrieves CPU, RAM, battery. | None | Read-only |
| `file_search` | Finds a file in the user directory. | `filename` (string), `dir` (optional) | User directory read |
| `memory_store` | Saves a new fact about the user. | `fact` (string) | Local DB write |

## 4. Emergency Fallbacks
- **API Downtime:** If the Cloud LLM times out or returns a 5xx error, the Brain Core immediately falls back to the Fast Intent Classifier. If the intent cannot be resolved locally, JARVIS responds: "I am currently disconnected from my main processing servers, sir."
- **Tool Failures:** If a tool throws an exception (e.g., application not found), the error is caught by the execution loop, fed back to the LLM as an Observation, and the LLM must generate an apologetic response.
- **Voice Cancellation:** The user can say "Cancel that" or "Stop" at any time. The Brain Core must listen for this global interrupt flag, immediately terminate any active ReAct loop or pending tool execution, and clear the current context turn.

## Implementation Status (Phase 1 + Phase 2)

**Status**: COMPLETE (Phase 1 + Phase 2)

**Implemented**:
- ReAct loop (`core/brain.py`): full Thought → Action → Observation → Response cycle.
- LLM client (`core/llm.py`): DeepSeek via `AsyncOpenAI` with timeout and error handling.
- Rolling context window: last 20 messages kept in-memory, system prompt always prepended.
- Tool schema formatter: outputs OpenAI-compatible function-calling schema from `TOOLS` registry.
- Confirmation gate: destructive tools (`requires_confirmation=True`) prompt user before execution.
- Cancel handling: "cancel", "stop", "abort", "nevermind" short-circuit the ReAct loop.
- Operative alert injection: ContinuousOperative alerts prepended to context before LLM call.
- Tool-call rate limiter: MAX_TOOL_CALLS_PER_TURN (default: 5) enforced.

**Architecture Preserved**:
- Brain is purely orchestration — it does not contain LLM logic (in `core/llm.py`) or tool logic (in `tools/`).
- LLM provider (DeepSeek) is swappable: change `core/llm.py` without touching Brain.

**Known Limitations**:
- Fast Intent Classifier (local lightweight model) is not yet implemented. Fallback is a canned error string on API failure.
- Context is in-memory only (no cross-session persistence until Phase 3).

**Last Verified**: 2026-09-11
