# Engineering Rules & Guidelines

## 1. Allowed Tech Stack
- **Language:** Python 3.11+
- **Concurrency:** `asyncio` for non-blocking I/O and event loop management.
- **Audio/Voice:** 
  - `faster-whisper` for local, low-latency STT.
  - `edge-tts` (or local equivalent) for crisp TTS.
- **OS Interaction:** `PyAutoGUI`, `psutil` (for system stats), and standard Windows OS APIs.
- **Data Storage:** 
  - `SQLite` for relational data (settings, logs).
  - `ChromaDB` (or similar lightweight vector store) for semantic long-term memory.
- **API/Server:** `FastAPI` (for internal modular communication or optional web UI).

## 2. Strictly Forbidden
- **Elevation of Privilege:** NEVER request, prompt for, or execute under Administrator, Root, or elevated UAC privileges.
- **Arbitrary Code Execution:** Running unvalidated strings via `eval()`, `exec()`, or direct shell injection (`os.system(llm_output)`) is strictly prohibited. Use parameterized functions and predefined tool schemas.
- **Blocking the Event Loop:** No synchronous, blocking I/O calls (e.g., heavy file reads, synchronous network requests) on the main `asyncio` event loop. Offload to threads or use async equivalents.

## 3. Error Handling
- **Crash Recovery:** Critical components (Audio Engine, OS Runner) must run in isolated tasks/processes with automatic restart policies upon failure.
- **API Fallback Strategies:** If the primary cloud LLM fails, fallback to a local lightweight model or a predefined set of rule-based responses for core OS commands.
- **Spoken Error Alerts:** System errors should be communicated to the user gracefully in the JARVIS persona (e.g., "I'm having trouble accessing the network at the moment, sir.").

## 4. AI Safety Boundaries
- **Destructive Operations:** Any tool call that deletes files, modifies critical system settings, or closes applications with unsaved work MUST trigger a confirmation prompt (e.g., "Are you sure you want me to delete this directory?").
- **Execution Timeouts:** All OS tool executions must have strict timeouts (e.g., max 5 seconds). If a command hangs, it must be killed, and the Brain Core notified.
- **Rate Limiting:** Prevent the LLM from entering infinite loops of tool calling by capping the maximum number of actions per user request.
