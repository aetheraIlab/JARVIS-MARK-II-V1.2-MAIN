# Product Requirements Document (PRD)

## Project Name
**JARVIS MARK II (v1.2)** - *Joint Autonomous Responsive Virtual Intelligence System*

## 1. Vision & Design Philosophy
JARVIS MARK II is designed to be a voice-first, highly responsive personal AI assistant. Inspired by the AI from Iron Man, the design philosophy centers on delivering a seamless, low-latency, and natural conversational experience while possessing the capability to orchestrate tasks and control the local desktop environment. It acts as an intelligent layer between the user and their operating system, prioritizing speed, reliability, and an intuitive user experience.

## 2. Target User Persona & Operating Environment
- **Target Audience:** Strictly for single-user personal use (Custom personal assistant).
- **Primary Persona:** Power users, developers, or professionals who want hands-free control over their local environment, quick access to information, and automated workflows.
- **Operating Environment:** Windows PC environment (user-level access), running continuously in the background with an optional minimal visual HUD.

## 3. Functional Requirements

### 3.1 Voice I/O
- **Wake-Word Detection:** Continuous, low-resource local listening for a specific wake-word (e.g., "JARVIS").
- **Speech-to-Text (STT):** High-accuracy transcription of user commands.
- **Text-to-Speech (TTS):** Natural, high-quality voice synthesis matching the JARVIS persona.
- **Barge-in Support:** Ability for the user to interrupt JARVIS while it is speaking, immediately halting the current action/speech and listening for new input.

### 3.2 User-level PC Control
- **Application Management:** Open, close, and switch between standard user applications.
- **Media Control:** Play, pause, skip, and volume control.
- **File Navigation:** Search for and open files/folders within user directories.
- **System Diagnostics:** Monitor system health (CPU, RAM, disk usage, battery) and report status.
- **Constraint:** All controls must strictly operate within standard user-level permissions. No administrator/root privileges are required or allowed.

### 3.3 OpenJarvis Agent Integrations
To expand core capabilities robustly, the following agent patterns from the OpenJarvis framework will be adapted and integrated, tailored to our lightweight Python stack (`asyncio`, `Faster-Whisper`, `Edge-TTS`, `DeepSeek API`):
- **Morning Digest Agent:** A scheduled background briefing engine providing email summaries, system health checks, and local news via TTS.
- **Deep Research Agent:** A multi-hop document and web research tool with citation indexing.
- **Code Assistant Agent:** A secure local file editing and non-admin command execution runner.
- **Continuous Operative / Monitor:** A background task monitoring loop running inside the async scheduler.

### 3.4 Future-Proofing (Vision Specs)
- **Modular Architecture:** Core components must be loosely coupled to allow seamless addition of future modules.
- **Computer Vision Readiness:** The system must define interfaces for future integration of screen reading (OCR, UI element detection) and camera feed analysis for contextual awareness.

## 4. Non-Functional Requirements

### 4.1 Performance & Latency
- **Voice Response Latency:** Target < 1.5s from the end of the user's speech to the beginning of the TTS output.
- **Execution Latency:** Local OS commands should execute within 500ms of intent resolution.

### 4.2 Resource Utilization
- **Low RAM/CPU Usage:** The background listening and core orchestration processes must consume minimal system resources to avoid interfering with primary user tasks. Heavy inference (like STT or LLM) should be optimized (e.g., quantized models) or offloaded where appropriate.

### 4.3 Security & Privacy
- **User-Level Sandboxing:** The assistant must run without elevated privileges.
- **Local Priority:** Sensitive data and memory should be stored locally.
- **Confirmation Protocols:** Destructive actions (e.g., deleting files, closing unsaved work) must require explicit voice confirmation.

## Implementation Status (V1.2 — RELEASE READY)

**Status**: ALL REQUIREMENTS MET

### 3.1 Voice I/O — COMPLETE
- Wake-word detection: VAD + Whisper tiny.en in `audio/stt.py`
- STT: faster-whisper with VAD recording and 1.5s silence detection
- TTS: edge-tts + pygame with barge-in support in `audio/tts.py`
- Barge-in: `AudioState.barge_in_event` interrupts TTS playback immediately

### 3.2 User-Level PC Control — COMPLETE (8 tools)
- Application Management: `launch_application` (15-app whitelist, `os.startfile`)
- Media Control: `media_control` (Windows VK codes via ctypes)
- File Navigation: `file_search`, `read_file`, `write_file` (user home only)
- System Diagnostics: `get_system_status`, `get_battery`, `get_time_date`
- Constraint satisfied: all tools enforce user-home path restriction, no admin elevation

### 3.3 OpenJarvis Agent Integrations — COMPLETE
- Morning Digest Agent: `agents/morning_digest.py`, TTS delivery, 08:00 default schedule
- Deep Research Agent: `agents/deep_research.py`, ChromaDB-backed semantic research with citations
- Code Assistant Agent: `agents/code_assistant.py`, path-restricted file editing + whitelisted commands
- Continuous Operative: `agents/operative.py`, 30s background polling, CPU/RAM/battery alerts

### 3.4 Future-Proofing — COMPLETE (Architecture defined)
- `process_intent(image_bytes=...)` interface in `core/brain.py` for VLM readiness
- Loose coupling: Brain, LLM, Tools, Agents all separate modules

### 4.1 Performance — VERIFIED
- Faster-Whisper tiny.en: lowest possible STT latency
- DeepSeek API timeout: 15s max (config/settings.py LLM_TIMEOUT_SECONDS)
- All tool timeouts enforced via asyncio.wait_for (5–30s per tool)

### 4.2 Resource Utilization — VERIFIED
- Whisper model loaded once at module level (no re-init per turn)
- ChromaDB local persistence (no network)
- HUD runs in daemon thread (no asyncio blocking)

### 4.3 Security & Privacy — VERIFIED
- No shell=True with dynamic strings anywhere in codebase
- No eval()/exec() of LLM output
- User-home boundary enforced in every file-touching tool
- write_file has requires_confirmation=True, Brain gates before execution
- No admin/UAC elevation anywhere

**Last Verified**: 2026-09-11
