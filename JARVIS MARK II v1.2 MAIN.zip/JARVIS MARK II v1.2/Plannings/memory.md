# Memory Subsystem

## 1. Short-Term Memory
- **Purpose:** Maintain context for the current conversation, handle multi-turn queries, and track the active task state.
- **Mechanism:** A rolling sliding window of the last *N* interactions (e.g., last 10 messages).
- **Pruning:** When the window exceeds the token limit, the oldest messages are summarized and compressed into a single "context" string, or simply dropped if deemed irrelevant to the current task.

## 2. Long-Term Memory
- **Purpose:** Store persistent knowledge, user preferences, custom tool aliases, and historical facts across sessions.
- **Mechanism:** A hybrid approach using a relational database and a semantic vector store.

## 3. Database Schemas

### 3.1 Relational Store (SQLite)
Used for structured, key-value style preferences and system configurations.

**Table: `user_preferences`**
- `id` (INT, PK)
- `key` (VARCHAR) - e.g., "preferred_browser", "address_title"
- `value` (VARCHAR)
- `updated_at` (TIMESTAMP)

**Table: `custom_aliases`**
- `id` (INT, PK)
- `voice_command` (VARCHAR) - e.g., "Initiate work mode"
- `mapped_actions` (JSON) - e.g., `["launch:slack", "launch:vscode", "media:play_focus_playlist"]`

### 3.2 Semantic Vector Store (ChromaDB)
Used for unstructured facts and semantic retrieval.

**Collection: `user_facts`**
- `id`: UUID
- `embedding`: Vector representation of the document
- `document`: The factual text (e.g., "User's current main project is JARVIS MARK II.")
- `metadata`: `{"timestamp": "...", "source": "conversation", "importance_score": 0.8}`

### 3.3 Retrieval & Pruning Rules
- **Retrieval:** Before routing to the LLM, the Brain Core queries the Vector DB using the user's current prompt to fetch top-K relevant facts and injects them into the system prompt.
- **Pruning/Updating:** If a new fact contradicts an old fact (e.g., "My favorite color is now red" vs "favorite color is blue"), a background LLM process flags the old fact for deletion/update to prevent context pollution.

## Implementation Status (Phase 3)

**Status**: COMPLETE

**Implemented**:
- **SQLiteMemory** (`core/memory.py`): Fully handles `user_preferences` and `custom_aliases` schema using thread-safe async I/O.
- **ChromaMemory** (`core/memory.py`): Semantic vector store initialized locally (`.jarvis_memory/chroma`). Implements `store_fact`, `query_facts`, `delete_fact`.
- **MemoryManager** (`core/memory.py`): Unified interface for both stores, capable of formatting contexts for the LLM.
- **Tools Integration** (`tools/memory_tools.py`): `memory_store_fact`, `memory_recall`, `memory_set_preference`, `memory_get_preference`, `memory_set_alias`, `memory_get_alias`, `deep_research` all wired into the ReAct loop.
- **Context Injection**: Pre-LLM retrieval is implemented in `core/brain.py` `process_intent()`.

**Known Limitations**:
- Pruning/Updating (contradiction detection) relies on the ReAct loop LLM explicitly deciding to delete/update an old fact using tools. True background autonomous contradiction-sweeping is not implemented yet.

**Last Verified**: 2026-09-11

