"""
main.py — JARVIS MARK II v1.2 entry point.

Starts:
 - Continuous Operative background monitor
 - Wake-word detection loop
 - Full voice conversation loop (STT → Brain → TTS)
"""

import asyncio
from core.brain import process_intent
from audio.stt import listen_for_input
from audio.tts import speak
from utils.logger import get_logger
from utils.audio_utils import audio_state, SystemState

logger = get_logger("main")


async def run_jarvis():
    logger.info("Starting JARVIS MARK II (v1.2)...")

    # Start the Continuous Operative background monitor
    try:
        from agents.operative import operative
        operative.start()
        logger.info("Continuous Operative is active.")
    except Exception as e:
        logger.warning(f"Operative failed to start: {e}")

    # Start the Morning Digest Agent (scheduled for 08:00 by default)
    try:
        from agents.morning_digest import morning_digest
        morning_digest.start()
        logger.info("Morning Digest Agent is scheduled.")
    except Exception as e:
        logger.warning(f"Morning Digest Agent failed to start: {e}")

    # Start HUD Overlay
    try:
        from ui.hud import hud
        hud.start()
        logger.info("HUD Overlay is active.")
    except Exception as e:
        logger.warning(f"HUD Overlay failed to start: {e}")

    await speak("Systems are online and ready, Sir.")

    is_awake = False

    while True:
        try:
            if not is_awake:
                # Wait for wake word ("JARVIS") using Whisper VAD mode
                audio_state.set_state(SystemState.IDLE)
                user_text = await listen_for_input(wake_word_mode=True)
                if not user_text or not user_text.strip():
                    continue
                is_awake = True
            else:
                # Awake: wait for a command (5s idle timeout)
                audio_state.set_state(SystemState.LISTENING)
                user_text = await listen_for_input(wake_word_mode=False)
                if not user_text or not user_text.strip():
                    # Silence/timeout — go back to sleep
                    is_awake = False
                    logger.info("No command received. Returning to idle.")
                    audio_state.set_state(SystemState.IDLE)
                    continue

            text_lower = user_text.lower().strip().replace(".", "")

            # Shutdown commands
            if text_lower in [
                "exit", "quit", "shut down", "shutdown",
                "jarvis exit", "jarvis quit", "jarvis shut down",
            ]:
                audio_state.set_state(SystemState.PROCESSING)
                await speak("Shutting down. Goodbye, Sir.")
                break

            # Clear any residual barge-in state
            audio_state.barge_in_event.clear()

            # Process intent through the Brain
            audio_state.set_state(SystemState.PROCESSING)
            response_text = await process_intent(user_text)
            if response_text:
                await speak(response_text)

            # After response, stay awake for follow-up
            # (is_awake remains True)

        except asyncio.CancelledError:
            logger.info("JARVIS shut down (CancelledError).")
            break
        except Exception as e:
            logger.error(f"Unexpected error in main loop: {e}")
            await speak(f"I encountered an unexpected error, Sir. Please check the logs.")
            await asyncio.sleep(2)

    # Cleanup
    try:
        from agents.operative import operative
        operative.stop()
    except Exception:
        pass

    try:
        from agents.morning_digest import morning_digest
        morning_digest.stop()
    except Exception:
        pass


    logger.info("JARVIS MARK II shut down cleanly.")


if __name__ == "__main__":
    try:
        asyncio.run(run_jarvis())
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received. Exiting.")
