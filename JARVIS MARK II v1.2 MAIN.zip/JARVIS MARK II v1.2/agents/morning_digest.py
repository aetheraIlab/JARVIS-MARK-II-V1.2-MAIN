"""
Morning Digest Agent — scheduled proactive briefing for JARVIS MARK II.

Runs as an asyncio background task. At the scheduled time (default 08:00),
generates a spoken morning briefing containing:
  - System health status (CPU, RAM, disk, battery)
  - Current time and date
  - Any pending Continuous Operative alerts
  - A user-configurable greeting from memory preferences

Integrates with:
  - tools/system_tools.py (system status, time)
  - agents/operative.py (alert queue)
  - core/memory.py (user preferences — user name, etc.)
  - audio/tts.py (TTS delivery)

Schedule: Configurable via DIGEST_HOUR / DIGEST_MINUTE in config/settings.py
"""

import asyncio
from datetime import datetime
from utils.logger import get_logger

logger = get_logger("morning_digest")


class MorningDigestAgent:
    """Delivers a scheduled morning briefing via TTS."""

    def __init__(self, hour: int = 8, minute: int = 0):
        self._hour = hour
        self._minute = minute
        self._task = None
        self._running = False

    def start(self) -> None:
        if self._task and not self._task.done():
            return
        self._running = True
        self._task = asyncio.create_task(
            self._scheduler_loop(), name="morning_digest"
        )
        logger.info(f"Morning Digest Agent scheduled for {self._hour:02d}:{self._minute:02d}.")

    def stop(self) -> None:
        self._running = False
        if self._task and not self._task.done():
            self._task.cancel()
        logger.info("Morning Digest Agent stopped.")

    async def _scheduler_loop(self) -> None:
        while self._running:
            now = datetime.now()
            if now.hour == self._hour and now.minute == self._minute:
                try:
                    await self.deliver()
                except Exception as e:
                    logger.error(f"Morning digest delivery failed: {e}")
                # Sleep 61s to avoid re-triggering in the same minute
                await asyncio.sleep(61)
            else:
                await asyncio.sleep(30)

    async def deliver(self) -> str:
        """Build and deliver the morning briefing. Returns the text spoken."""
        lines = []
        now = datetime.now()

        # Greeting
        hour = now.hour
        if hour < 12:
            greeting = "Good morning"
        elif hour < 17:
            greeting = "Good afternoon"
        else:
            greeting = "Good evening"

        # User title from preferences
        user_title = "Sir"
        try:
            from core.memory import memory_manager
            pref = await memory_manager.sqlite.get_preference("address_title")
            if pref:
                user_title = pref
        except Exception:
            pass

        lines.append(f"{greeting}, {user_title}. Here is your morning digest.")
        lines.append(f"Today is {now.strftime('%A, %B %d, %Y')} and the time is {now.strftime('%I:%M %p')}.")

        # System status
        try:
            import psutil
            cpu = psutil.cpu_percent(interval=0.5)
            ram = psutil.virtual_memory().percent
            lines.append(f"System status: CPU at {cpu:.0f}%, RAM at {ram:.0f}%.")

            batt = psutil.sensors_battery()
            if batt:
                status = "charging" if batt.power_plugged else "on battery"
                lines.append(f"Battery is at {batt.percent:.0f}%, {status}.")
        except Exception as e:
            logger.warning(f"System stats failed in digest: {e}")

        # Operative alerts
        try:
            from agents.operative import operative
            if operative.has_alerts():
                report = operative.get_report(clear=True)
                lines.append(f"Pending alerts: {report}")
        except Exception:
            pass

        lines.append("That concludes your morning digest. Have a productive day.")

        briefing = " ".join(lines)
        logger.info(f"Delivering morning digest: {briefing[:80]}...")

        # Deliver via TTS
        try:
            from audio.tts import speak
            await speak(briefing)
        except Exception as e:
            logger.error(f"TTS delivery failed: {e}")

        return briefing


# Singleton
morning_digest = MorningDigestAgent(hour=8, minute=0)
