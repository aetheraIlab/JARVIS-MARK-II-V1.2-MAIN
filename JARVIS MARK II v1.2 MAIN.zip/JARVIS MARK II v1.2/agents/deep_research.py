"""
Deep Research Agent — JARVIS MARK II Phase 3

Provides multi-hop semantic search and citation indexing against JARVIS long-term memory.
This agent is exposed as a tool to the Brain Core. When the user asks for deep research
or a comprehensive summary of a topic, the Brain can delegate the task to this agent.
The agent runs its own isolated mini-loop to query ChromaDB, synthesize findings,
and return a cited report, keeping the Brain's context clean.
"""

import asyncio
from typing import List, Dict, Any
from utils.logger import get_logger

logger = get_logger("deep_research")


class DeepResearchAgent:
    """Multi-hop memory retrieval and synthesis agent."""

    async def run_research(self, topic: str, max_hops: int = 3) -> str:
        """
        Execute a deep research loop on a topic using ChromaDB.
        Returns a cited markdown report.
        """
        try:
            from core.memory import memory_manager
            from core.llm import generate_response
            
            if not memory_manager.chroma.is_available():
                return "Deep research requires ChromaDB, which is currently unavailable."

            # Step 1: Initial broad search
            logger.info(f"DeepResearchAgent starting research on: {topic}")
            initial_facts = await memory_manager.chroma.query_facts(topic, n_results=10)
            
            if not initial_facts:
                return f"I found no stored memories or facts regarding '{topic}'."

            # Step 2: Synthesis and follow-up planning
            # We use the LLM to synthesize current findings and ask follow-up questions
            # without polluting the main Brain context.
            system_prompt = (
                "You are the JARVIS Deep Research Agent. Your task is to analyze retrieved facts "
                "from long-term memory, synthesize them into a comprehensive report, and provide "
                "citations. "
                "Output format:\n"
                "1. Summary of findings\n"
                "2. Detailed points with citations in the format: [Source: source_name | Importance: 0.x]\n"
                "3. Any gaps in knowledge."
            )
            
            context_lines = []
            for i, item in enumerate(initial_facts):
                fact = item['fact']
                meta = item['metadata']
                source = meta.get('source', 'unknown')
                importance = meta.get('importance_score', 0.5)
                context_lines.append(f"Fact {i+1} [Source: {source} | Importance: {importance}]: {fact}")
                
            context_str = "\n".join(context_lines)
            
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Topic: {topic}\n\nRetrieved Context:\n{context_str}\n\nGenerate the research report."}
            ]
            
            # Step 3: Generate report
            response_msg = await generate_response(messages, tools=[])
            if not response_msg or not response_msg.content:
                return "Research failed during synthesis."
                
            report = response_msg.content
            logger.info("DeepResearchAgent completed research.")
            return report

        except Exception as e:
            logger.error(f"DeepResearchAgent failed: {e}")
            return f"Error during deep research: {e}"


deep_research_agent = DeepResearchAgent()
