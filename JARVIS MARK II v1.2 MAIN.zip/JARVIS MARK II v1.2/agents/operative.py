"""
Continuous Operative — background async monitoring agent for JARVIS MARK II.

Runs as an asyncio background task. Periodically checks system health and
stores alerts. Brain can query the latest report via get_operative_report().

Responsibilities:
  - Monitor CPU / RAM for threshold breaches
  - Monitor battery level
  - Accumulate alerts for Brain to surface via TTS
  - Never block the main event loop
"""

import asyncio
import psutil
from datetime import datetime
from typing import List, Optional
from utils.logger import get_logger

logger = get_logger("operative")

# Alert thresholds
CPU_ALERT_THRESHOLD = 90.0   # %
RAM_ALERT_THRESHOLD = 90.0   # %
BATTERY_LOW_THRESHOLD = 15.0 # %
POLL_INTERVAL_SECONDS = 30   # how often to check


class ContinuousOperative:
    """Background system monitor that accumulates alerts."""

    def __init__(self):
        self._alerts: List[str] = []
        self._task: Optional[asyncio.Task] = None
        self._running = False

    def start(self) -> None:
        """Start the background monitoring loop as an asyncio task."""
        if self._task and not self._task.done():
            return  # already running
        self._running = True
        self._task = asyncio.create_task(self._monitor_loop(), name="operative_monitor")
        logger.info("Continuous Operative started.")

    def stop(self) -> None:
        """Stop the background monitoring loop."""
        self._running = False
        if self._task and not self._task.done():
            self._task.cancel()
        logger.info("Continuous Operative stopped.")

    def get_report(self, clear: bool = True) -> str:
        """Return pending alerts and optionally clear them."""
        if not self._alerts:
            return ""
        report = " | ".join(self._alerts)
        if clear:
            self._alerts.clear()
        return report

    def has_alerts(self) -> bool:
        return bool(self._alerts)

    def _push_alert(self, msg: str) -> None:
        timestamp = datetime.now().strftime("%H:%M")
        full = f"[{timestamp}] {msg}"
        self._alerts.append(full)
        logger.warning(f"Operative alert: {full}")

    async def _monitor_loop(self) -> None:
        while self._running:
            try:
                await self._check_system()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Operative monitor error: {e}")
            await asyncio.sleep(POLL_INTERVAL_SECONDS)

    async def _check_system(self) -> None:
        # Run blocking psutil calls in a thread
        cpu, ram, batt = await asyncio.to_thread(self._collect_stats)

        if cpu is not None and cpu >= CPU_ALERT_THRESHOLD:
            self._push_alert(f"High CPU usage: {cpu:.0f}%")

        if ram is not None and ram >= RAM_ALERT_THRESHOLD:
            self._push_alert(f"High RAM usage: {ram:.0f}%")

        if batt is not None and batt <= BATTERY_LOW_THRESHOLD:
            self._push_alert(f"Low battery: {batt:.0f}% — please plug in.")

    @staticmethod
    def _collect_stats():
        """Collect system stats synchronously (runs in thread pool)."""
        try:
            cpu = psutil.cpu_percent(interval=1)
        except Exception:
            cpu = None
        try:
            ram = psutil.virtual_memory().percent
        except Exception:
            ram = None
        try:
            b = psutil.sensors_battery()
            batt = b.percent if b else None
        except Exception:
            batt = None
        return cpu, ram, batt


# Singleton operative instance used by Brain
operative = ContinuousOperative()
