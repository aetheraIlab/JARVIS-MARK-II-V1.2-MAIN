"""
Code Assistant Agent — secure local file editing for JARVIS MARK II.

Capabilities:
  - Read files (user home only)
  - Write/append to files (user home only, requires prior confirmation)
  - List directory contents (user home only)
  - Run safe, whitelisted commands (no arbitrary shell injection)

Security rules enforced (rules.md §2, §4):
  - All paths restricted to user home directory
  - No eval/exec of LLM output
  - No admin/UAC elevation
  - Destructive writes require confirmation flag set by brain
  - Command execution uses parameterized list form only (no shell=True with strings)
"""

import asyncio
import os
import subprocess
from pathlib import Path
from typing import Optional
from utils.logger import get_logger

logger = get_logger("code_assistant")

USER_HOME = Path.home()

# Whitelisted safe commands that can be run (no arbitrary LLM strings)
_ALLOWED_COMMANDS = {
    "python --version",
    "python -m pytest",
    "pip list",
    "dir",
    "ls",
    "echo",
}

TOOL_TIMEOUT = 8.0  # seconds


def _assert_user_path(path_str: str) -> Path:
    p = Path(path_str).expanduser().resolve()
    try:
        p.relative_to(USER_HOME)
    except ValueError:
        raise PermissionError(
            f"Access denied: '{path_str}' is outside the user home directory."
        )
    return p


class CodeAssistantAgent:
    """Secure local file editing and inspection agent."""

    def __init__(self):
        self._confirmed_paths: set = set()  # paths user has confirmed to overwrite

    async def read_file(self, path: str, max_chars: int = 4000) -> str:
        """Read a file within user home directory."""
        try:
            p = _assert_user_path(path)
            if not p.exists():
                return f"File not found: '{path}'"
            if not p.is_file():
                return f"'{path}' is not a file."
            content = await asyncio.wait_for(
                asyncio.to_thread(lambda: p.read_text(encoding="utf-8", errors="replace")),
                timeout=TOOL_TIMEOUT
            )
            if len(content) > max_chars:
                content = content[:max_chars] + f"\n... [truncated at {max_chars} chars]"
            return content
        except PermissionError as e:
            return str(e)
        except asyncio.TimeoutError:
            return f"Timed out reading '{path}'."
        except Exception as e:
            logger.error(f"read_file error: {e}")
            return f"Error reading file: {e}"

    async def write_file(self, path: str, content: str, mode: str = "write", confirmed: bool = False) -> str:
        """Write or append to a file. Requires confirmed=True for overwrites."""
        try:
            p = _assert_user_path(path)

            # Confirmation gate for destructive writes
            if mode == "write" and p.exists() and not confirmed:
                return (
                    f"CONFIRMATION REQUIRED: '{p.name}' already exists and will be overwritten. "
                    f"Please confirm by saying 'yes' or 'confirm'."
                )

            write_mode = "w" if mode == "write" else "a"
            await asyncio.wait_for(
                asyncio.to_thread(lambda: open(p, write_mode, encoding="utf-8").write(content)),
                timeout=TOOL_TIMEOUT
            )
            return f"Successfully wrote to '{path}'."
        except PermissionError as e:
            return str(e)
        except asyncio.TimeoutError:
            return f"Timed out writing '{path}'."
        except Exception as e:
            logger.error(f"write_file error: {e}")
            return f"Error writing file: {e}"

    async def list_directory(self, path: str = "") -> str:
        """List contents of a directory within user home."""
        try:
            target = _assert_user_path(path) if path else USER_HOME
            if not target.is_dir():
                return f"'{path}' is not a directory."
            entries = await asyncio.to_thread(lambda: list(target.iterdir()))
            lines = []
            for e in sorted(entries)[:50]:  # cap at 50 entries
                kind = "[DIR] " if e.is_dir() else "[FILE]"
                lines.append(f"{kind} {e.name}")
            if not lines:
                return "Directory is empty."
            return "\n".join(lines)
        except PermissionError as e:
            return str(e)
        except Exception as e:
            logger.error(f"list_directory error: {e}")
            return f"Error listing directory: {e}"

    async def run_safe_command(self, command: str, working_dir: str = "") -> str:
        """
        Run a strictly whitelisted command (no arbitrary shell execution).
        command must be in _ALLOWED_COMMANDS or start with an allowed prefix.
        """
        cmd_lower = command.strip().lower()
        allowed = any(cmd_lower == a or cmd_lower.startswith(a.split()[0] + " ")
                      for a in _ALLOWED_COMMANDS)
        if not allowed:
            return (
                f"Command '{command}' is not in the allowed command list. "
                "Arbitrary shell execution is forbidden by security policy."
            )

        cwd = None
        if working_dir:
            try:
                cwd = str(_assert_user_path(working_dir))
            except PermissionError as e:
                return str(e)

        try:
            result = await asyncio.wait_for(
                asyncio.to_thread(
                    lambda: subprocess.run(
                        command.split(),  # parameterized list — no shell=True
                        capture_output=True,
                        text=True,
                        cwd=cwd,
                        timeout=TOOL_TIMEOUT,
                    )
                ),
                timeout=TOOL_TIMEOUT + 1,
            )
            output = (result.stdout or "") + (result.stderr or "")
            return output.strip() or "(no output)"
        except subprocess.TimeoutExpired:
            return f"Command '{command}' timed out."
        except Exception as e:
            logger.error(f"run_safe_command error: {e}")
            return f"Error running command: {e}"
