"""
Memory Subsystem — JARVIS MARK II Phase 3

Implements the hybrid memory architecture from Plannings/memory.md:

  SQLiteMemory    — structured key-value preferences and custom aliases
  ChromaMemory    — semantic vector store for long-term user facts (ChromaDB)
  MemoryManager   — unified interface used by Brain and Memory tools

Data is stored under: {USER_HOME}/.jarvis_memory/

Security: All data is stored locally. No external transmission.
"""

import json
import sqlite3
import asyncio
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from utils.logger import get_logger

logger = get_logger("memory")

MEMORY_DIR = Path.home() / ".jarvis_memory"
MEMORY_DIR.mkdir(exist_ok=True)

DB_PATH = MEMORY_DIR / "jarvis.db"
CHROMA_PATH = str(MEMORY_DIR / "chroma")

# ---------------------------------------------------------------------------
# SQLite — structured preferences & custom aliases
# ---------------------------------------------------------------------------

class SQLiteMemory:
    """
    Manages user_preferences and custom_aliases tables per memory.md §3.1
    Runs all DB I/O in a thread to avoid blocking the event loop.
    """

    def __init__(self, db_path: Path = DB_PATH):
        self._db_path = str(db_path)
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        with self._connect() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS user_preferences (
                    id       INTEGER PRIMARY KEY AUTOINCREMENT,
                    key      TEXT NOT NULL UNIQUE,
                    value    TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS custom_aliases (
                    id            INTEGER PRIMARY KEY AUTOINCREMENT,
                    voice_command TEXT NOT NULL UNIQUE,
                    mapped_actions TEXT NOT NULL,
                    updated_at    TEXT NOT NULL
                );
            """)
        logger.info("SQLite memory initialized.")

    # --- Preferences ---

    def _set_preference_sync(self, key: str, value: str):
        now = datetime.now().isoformat()
        with self._connect() as conn:
            conn.execute(
                """INSERT INTO user_preferences (key, value, updated_at)
                   VALUES (?, ?, ?)
                   ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at""",
                (key, value, now),
            )

    def _get_preference_sync(self, key: str) -> Optional[str]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT value FROM user_preferences WHERE key = ?", (key,)
            ).fetchone()
            return row["value"] if row else None

    def _list_preferences_sync(self) -> List[Tuple[str, str]]:
        with self._connect() as conn:
            rows = conn.execute("SELECT key, value FROM user_preferences").fetchall()
            return [(r["key"], r["value"]) for r in rows]

    # --- Aliases ---

    def _set_alias_sync(self, voice_command: str, mapped_actions: List[str]):
        now = datetime.now().isoformat()
        with self._connect() as conn:
            conn.execute(
                """INSERT INTO custom_aliases (voice_command, mapped_actions, updated_at)
                   VALUES (?, ?, ?)
                   ON CONFLICT(voice_command) DO UPDATE
                   SET mapped_actions=excluded.mapped_actions, updated_at=excluded.updated_at""",
                (voice_command, json.dumps(mapped_actions), now),
            )

    def _get_alias_sync(self, voice_command: str) -> Optional[List[str]]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT mapped_actions FROM custom_aliases WHERE LOWER(voice_command) = LOWER(?)",
                (voice_command,),
            ).fetchone()
            return json.loads(row["mapped_actions"]) if row else None

    def _list_aliases_sync(self) -> List[Tuple[str, List[str]]]:
        with self._connect() as conn:
            rows = conn.execute("SELECT voice_command, mapped_actions FROM custom_aliases").fetchall()
            return [(r["voice_command"], json.loads(r["mapped_actions"])) for r in rows]

    # --- Async wrappers ---

    async def set_preference(self, key: str, value: str) -> None:
        await asyncio.to_thread(self._set_preference_sync, key, value)

    async def get_preference(self, key: str) -> Optional[str]:
        return await asyncio.to_thread(self._get_preference_sync, key)

    async def list_preferences(self) -> List[Tuple[str, str]]:
        return await asyncio.to_thread(self._list_preferences_sync)

    async def set_alias(self, voice_command: str, mapped_actions: List[str]) -> None:
        await asyncio.to_thread(self._set_alias_sync, voice_command, mapped_actions)

    async def get_alias(self, voice_command: str) -> Optional[List[str]]:
        return await asyncio.to_thread(self._get_alias_sync, voice_command)

    async def list_aliases(self) -> List[Tuple[str, List[str]]]:
        return await asyncio.to_thread(self._list_aliases_sync)


# ---------------------------------------------------------------------------
# ChromaDB — semantic long-term fact store
# ---------------------------------------------------------------------------

class ChromaMemory:
    """
    Semantic vector store for user facts per memory.md §3.2
    Uses ChromaDB with a local persistent client.
    Provides store_fact, query_facts (top-K semantic search), delete_fact.
    Falls back gracefully if chromadb is not installed.
    """

    COLLECTION_NAME = "user_facts"

    def __init__(self):
        self._client = None
        self._collection = None
        self._available = False
        self._init()

    def _init(self):
        try:
            import chromadb
            self._client = chromadb.PersistentClient(path=CHROMA_PATH)
            self._collection = self._client.get_or_create_collection(
                name=self.COLLECTION_NAME,
                metadata={"hnsw:space": "cosine"},
            )
            self._available = True
            logger.info("ChromaDB memory initialized.")
        except ImportError:
            logger.warning("ChromaDB not installed. Semantic memory disabled.")
        except Exception as e:
            logger.error(f"ChromaDB init failed: {e}")

    def is_available(self) -> bool:
        return self._available

    def _store_fact_sync(self, fact: str, source: str = "conversation",
                          importance: float = 0.8) -> str:
        if not self._available:
            return ""
        fact_id = str(uuid.uuid4())
        self._collection.add(
            documents=[fact],
            metadatas=[{
                "timestamp": datetime.now().isoformat(),
                "source": source,
                "importance_score": importance,
            }],
            ids=[fact_id],
        )
        return fact_id

    def _query_facts_sync(self, query: str, n_results: int = 5) -> List[Dict[str, Any]]:
        if not self._available:
            return []
        try:
            results = self._collection.query(
                query_texts=[query],
                n_results=min(n_results, self._collection.count()),
                include=["documents", "metadatas", "distances"],
            )
            facts = []
            for doc, meta, dist in zip(
                results["documents"][0],
                results["metadatas"][0],
                results["distances"][0],
            ):
                facts.append({"fact": doc, "metadata": meta, "distance": dist})
            return facts
        except Exception as e:
            logger.error(f"ChromaDB query failed: {e}")
            return []

    def _delete_fact_sync(self, fact_id: str) -> bool:
        if not self._available:
            return False
        try:
            self._collection.delete(ids=[fact_id])
            return True
        except Exception as e:
            logger.error(f"ChromaDB delete failed: {e}")
            return False

    def _count_sync(self) -> int:
        if not self._available:
            return 0
        return self._collection.count()

    async def store_fact(self, fact: str, source: str = "conversation",
                          importance: float = 0.8) -> str:
        return await asyncio.to_thread(self._store_fact_sync, fact, source, importance)

    async def query_facts(self, query: str, n_results: int = 5) -> List[Dict[str, Any]]:
        return await asyncio.to_thread(self._query_facts_sync, query, n_results)

    async def delete_fact(self, fact_id: str) -> bool:
        return await asyncio.to_thread(self._delete_fact_sync, fact_id)

    async def count(self) -> int:
        return await asyncio.to_thread(self._count_sync)


# ---------------------------------------------------------------------------
# Unified MemoryManager
# ---------------------------------------------------------------------------

class MemoryManager:
    """
    Unified interface to both SQLite and ChromaDB memory layers.
    Used by Brain and memory tools.
    """

    def __init__(self):
        self.sqlite = SQLiteMemory()
        self.chroma = ChromaMemory()

    async def retrieve_context_for(self, query: str, top_k: int = 5) -> str:
        """
        Retrieve relevant long-term facts for a query.
        Returns a formatted string suitable for injection into the system prompt.
        """
        facts = await self.chroma.query_facts(query, n_results=top_k)
        if not facts:
            return ""
        lines = ["[Long-term memory context:]"]
        for item in facts:
            lines.append(f"- {item['fact']}")
        return "\n".join(lines)


# Singleton
memory_manager = MemoryManager()
