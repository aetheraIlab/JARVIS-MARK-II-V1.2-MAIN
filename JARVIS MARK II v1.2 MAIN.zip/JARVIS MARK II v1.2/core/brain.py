"""
Brain Core — ReAct orchestration layer for JARVIS MARK II.

Responsibilities:
  - Maintain rolling conversation history (in-memory context window)
  - Format tools schema for LLM
  - Execute ReAct loop: Thought → Action → Observation → Response
  - Enforce tool-call rate limit (MAX_TOOL_CALLS_PER_TURN)
  - Handle confirmation gate for destructive tools (requires_confirmation=True)
  - Surface Continuous Operative alerts before final response
  - Delegate to LLM provider (DeepSeek via openai-compatible client)

Architecture: Brain is the orchestration layer; LLM is the cognitive provider.
Do NOT collapse these responsibilities into one module.
"""

import json
import asyncio
from typing import List, Dict, Any, Optional

from .llm import generate_response
from tools.system_tools import TOOLS as OS_TOOLS
from tools.memory_tools import MEMORY_TOOLS
from config.settings import USER_TITLE, MAX_TOOL_CALLS_PER_TURN
from utils.logger import get_logger

logger = get_logger("brain_core")

# Merge all tool registries
TOOLS = {**OS_TOOLS, **MEMORY_TOOLS}

# ---------------------------------------------------------------------------
# System prompt (persona + rules)
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = f"""You are JARVIS, a professional, witty, polite, and highly efficient personal AI assistant.
You address the user as "{USER_TITLE}".
Responses must be concise. Prioritize executing actions over explaining them.
Example: "Opening Spotify, {USER_TITLE}." NOT "I am now opening Spotify for you."
If an error occurs, be apologetic but actionable.
You run in a local Windows user environment. You have tools for OS control.

DESTRUCTIVE TOOL RULE:
- write_file is a destructive tool. Before calling write_file on an existing file,
  check if the user has confirmed. If they have NOT, respond asking for confirmation
  instead of calling the tool. Only call write_file when the user explicitly confirms.

CANCEL RULE:
- If the user says "cancel", "stop", "nevermind", or "abort", immediately stop
  all tool calls and respond with a cancellation acknowledgment.
"""

# ---------------------------------------------------------------------------
# Context window (in-memory rolling history)
# ---------------------------------------------------------------------------

MAX_HISTORY_MESSAGES = 20  # keep last 20 exchanges (rolling window)


class BrainContext:
    """Rolling in-memory conversation context."""

    def __init__(self):
        self._system = {"role": "system", "content": SYSTEM_PROMPT}
        self.history: List[Dict[str, Any]] = []
        # Track if a destructive action is pending confirmation
        self.pending_confirmation: Optional[str] = None

    def add_message(self, role: str, content: Optional[str] = None,
                    tool_calls=None, tool_call_id: Optional[str] = None):
        msg: Dict[str, Any] = {"role": role}
        if content is not None:
            msg["content"] = content
        if tool_calls:
            msg["tool_calls"] = tool_calls
        if tool_call_id:
            msg["tool_call_id"] = tool_call_id
        self.history.append(msg)
        # Prune old messages keeping system prompt first
        if len(self.history) > MAX_HISTORY_MESSAGES:
            self.history = self.history[-MAX_HISTORY_MESSAGES:]

    def get_full_history(self) -> List[Dict[str, Any]]:
        return [self._system] + self.history

    def clear_pending_confirmation(self):
        self.pending_confirmation = None


# Singleton context — persists across turns in a session
context = BrainContext()


# ---------------------------------------------------------------------------
# Tool schema formatter
# ---------------------------------------------------------------------------

def format_tools() -> List[Dict[str, Any]]:
    return [
        {
            "type": "function",
            "function": {
                "name": tool.name,
                "description": tool.description,
                "parameters": tool.schema_params,
            },
        }
        for tool in TOOLS.values()
    ]


# ---------------------------------------------------------------------------
# Confirmation gate
# ---------------------------------------------------------------------------

CONFIRMATION_PHRASES = {"yes", "confirm", "confirmed", "go ahead", "do it", "sure", "yep", "yeah"}
CANCEL_PHRASES = {"no", "cancel", "stop", "nevermind", "abort", "nope"}


def _is_confirmation(text: str) -> bool:
    return text.lower().strip().rstrip(".") in CONFIRMATION_PHRASES


def _is_cancellation(text: str) -> bool:
    t = text.lower().strip()
    return any(c in t for c in CANCEL_PHRASES)


# ---------------------------------------------------------------------------
# Main intent processor
# ---------------------------------------------------------------------------

async def process_intent(user_input: str, image_bytes: Optional[bytes] = None) -> str:
    """
    Process a user utterance through the ReAct loop.
    Accepts optional image_bytes (e.g., screenshot) for vision-capable models (Phase 4).
    Returns the final text response to be spoken.
    """
    # --- Operative alert injection ---
    try:
        from agents.operative import operative
        if operative.has_alerts():
            report = operative.get_report(clear=True)
            logger.info(f"Surfacing operative alert: {report}")
            # Prepend alert as a system note for the LLM
            alert_note = f"[System Alert: {report}]"
            context.add_message("system", content=alert_note)
    except Exception as e:
        logger.warning(f"Operative alert check failed: {e}")

    # --- Confirmation gate: check if user is responding to a pending confirm ---
    if context.pending_confirmation:
        pending_tool_name = context.pending_confirmation
        if _is_confirmation(user_input):
            context.clear_pending_confirmation()
            # Re-execute with confirmed flag — add user message and note
            context.add_message("user", content=f"{user_input} [confirmed]")
            # Let LLM know confirmation was given and retry
            context.add_message("system", content=f"User confirmed the destructive action: {pending_tool_name}. Proceed.")
        elif _is_cancellation(user_input):
            context.clear_pending_confirmation()
            context.add_message("user", content=user_input)
            msg = f"Understood, {USER_TITLE}. Action cancelled."
            context.add_message("assistant", content=msg)
            return msg
        else:
            # Treat as new intent, clear pending
            context.clear_pending_confirmation()
            msg_content = user_input + ("\n[Image payload attached]" if image_bytes else "")
            context.add_message("user", content=msg_content)
    else:
        msg_content = user_input + ("\n[Image payload attached]" if image_bytes else "")
        context.add_message("user", content=msg_content)

    # --- Cancel shortcut: if user says stop before we even start ---
    if _is_cancellation(user_input) and not context.pending_confirmation:
        msg = f"Alright, {USER_TITLE}. Standing by."
        context.add_message("assistant", content=msg)
        return msg

    tools_schema = format_tools()

    # --- Long-term memory context injection ---
    # Retrieve relevant facts from ChromaDB and inject into history as a system note
    try:
        from core.memory import memory_manager
        mem_context = await memory_manager.retrieve_context_for(user_input, top_k=5)
        if mem_context:
            context.add_message("system", content=mem_context)
            logger.debug(f"Injected memory context: {mem_context[:80]}...")
    except Exception as e:
        logger.warning(f"Memory context retrieval failed: {e}")

    # --- ReAct loop ---
    turn_count = 0
    while turn_count < MAX_TOOL_CALLS_PER_TURN:
        message = await generate_response(context.get_full_history(), tools_schema)

        if not message:
            error_msg = f"I am currently disconnected from my main processing servers, {USER_TITLE}."
            context.add_message("assistant", content=error_msg)
            return error_msg

        # --- No tool call: final response ---
        if not message.tool_calls:
            response_text = message.content or ""
            context.add_message("assistant", content=response_text)
            return response_text

        # --- Tool call(s) ---
        context.add_message(
            "assistant",
            content=message.content,
            tool_calls=[t.model_dump() for t in message.tool_calls],
        )

        for tool_call in message.tool_calls:
            func_name = tool_call.function.name
            try:
                args = json.loads(tool_call.function.arguments)
            except json.JSONDecodeError:
                args = {}

            logger.info(f"Tool call: {func_name}({args})")

            tool = TOOLS.get(func_name)
            if not tool:
                result_str = f"Tool '{func_name}' not found."
                context.add_message("tool", content=result_str, tool_call_id=tool_call.id)
                continue

            # --- Destructive tool confirmation gate ---
            if tool.requires_confirmation and context.pending_confirmation != func_name:
                # Ask for confirmation before executing
                context.pending_confirmation = func_name
                confirm_msg = (
                    f"I need your confirmation before proceeding with '{func_name}', {USER_TITLE}. "
                    f"This action may overwrite or modify data. Please say 'confirm' to proceed or 'cancel' to abort."
                )
                # Inject a tool result that explains the hold
                context.add_message("tool", content=confirm_msg, tool_call_id=tool_call.id)
                context.add_message("assistant", content=confirm_msg)
                return confirm_msg

            # --- Execute tool with timeout already enforced by Tool.execute() ---
            try:
                result = await tool.execute(**args)
                result_str = str(result)
            except Exception as e:
                logger.error(f"Tool {func_name} raised exception: {e}")
                result_str = f"Error executing '{func_name}': {e}"

            context.add_message("tool", content=result_str, tool_call_id=tool_call.id)

        turn_count += 1

    # Exceeded tool call limit
    limit_msg = f"I reached my operation limit for this request, {USER_TITLE}. Please try a simpler command."
    context.add_message("assistant", content=limit_msg)
    return limit_msg
