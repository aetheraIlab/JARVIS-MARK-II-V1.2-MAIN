import asyncio
from openai import AsyncOpenAI, APITimeoutError, APIError
from config.settings import DEEPSEEK_API_KEY, DEEPSEEK_API_BASE, MODEL_NAME, LLM_TIMEOUT_SECONDS
from utils.logger import get_logger
from typing import List, Dict, Any, Optional

logger = get_logger("llm_engine")

client = AsyncOpenAI(api_key=DEEPSEEK_API_KEY, base_url=DEEPSEEK_API_BASE)

async def generate_response(messages: List[Dict[str, Any]], tools: Optional[List[Dict[str, Any]]] = None) -> Any:
    try:
        kwargs: Dict[str, Any] = {
            "model": MODEL_NAME,
            "messages": messages,
            "timeout": LLM_TIMEOUT_SECONDS
        }
        if tools:
            kwargs["tools"] = tools
            
        response = await client.chat.completions.create(**kwargs)
        return response.choices[0].message
    except APITimeoutError:
        logger.error("LLM API Timeout.")
        return None
    except APIError as e:
        logger.error(f"LLM API Error: {e}")
        return None
    except Exception as e:
        logger.error(f"Unexpected LLM error: {e}")
        return None
