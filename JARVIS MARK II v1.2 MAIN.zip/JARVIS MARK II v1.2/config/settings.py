import os

DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "your-api-key")
DEEPSEEK_API_BASE = os.getenv("DEEPSEEK_API_BASE", "https://api.deepseek.com")
MODEL_NAME = os.getenv("MODEL_NAME", "deepseek-chat")
USER_TITLE = os.getenv("USER_TITLE", "Sir")
WAKE_WORD = os.getenv("WAKE_WORD", "jarvis")

LLM_TIMEOUT_SECONDS = 15
MAX_TOOL_CALLS_PER_TURN = 5
