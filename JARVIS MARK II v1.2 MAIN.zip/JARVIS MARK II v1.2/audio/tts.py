import asyncio
import edge_tts
import pygame
import tempfile
import os
from utils.logger import get_logger
from utils.audio_utils import audio_state

logger = get_logger("tts_engine")
VOICE = "en-GB-RyanNeural"  

async def speak(text: str):
    if not text:
        return
        
    logger.info(f"JARVIS speaking: {text}")
    audio_state.set_speaking(True)
    temp_file = tempfile.mktemp(suffix=".mp3")
    
    try:
        communicate = edge_tts.Communicate(text, VOICE)
        await communicate.save(temp_file)
        
        if not pygame.mixer.get_init():
            pygame.mixer.init()
            
        pygame.mixer.music.load(temp_file)
        pygame.mixer.music.play()
        
        while pygame.mixer.music.get_busy():
            if audio_state.barge_in_event.is_set():
                logger.info("Barge-in detected! Stopping TTS playback.")
                pygame.mixer.music.stop()
                break
            await asyncio.sleep(0.05)
            
    except Exception as e:
        logger.error(f"TTS Error: {e}")
    finally:
        audio_state.set_speaking(False)
        if os.path.exists(temp_file):
            try:
                await asyncio.sleep(0.1) 
                os.remove(temp_file)
            except OSError:
                pass
