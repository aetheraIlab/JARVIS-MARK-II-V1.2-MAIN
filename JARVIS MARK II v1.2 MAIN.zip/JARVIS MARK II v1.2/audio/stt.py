import asyncio
from concurrent.futures import ThreadPoolExecutor
from faster_whisper import WhisperModel
import pyaudio
import wave
import tempfile
import os
import math
import struct
from utils.logger import get_logger
from utils.audio_utils import audio_state

logger = get_logger("stt_engine")

try:
    model = WhisperModel("tiny.en", device="cpu", compute_type="int8")
except Exception as e:
    logger.error(f"Failed to load Whisper model: {e}")
    model = None

executor = ThreadPoolExecutor(max_workers=1)

def get_rms(data: bytes) -> float:
    count = len(data) // 2
    if count == 0:
        return 0.0
    shorts = struct.unpack(f"{count}h", data)
    sum_squares = sum(s**2 for s in shorts)
    return math.sqrt(sum_squares / count)

def record_utterance_to_file(filename: str, max_duration: int = 15, idle_timeout: int = 5):
    chunk = 1024
    sample_format = pyaudio.paInt16
    channels = 1
    fs = 16000
    p = pyaudio.PyAudio()

    stream = p.open(format=sample_format, channels=channels, rate=fs, frames_per_buffer=chunk, input=True)
    frames = []
    
    silence_threshold = 500
    max_silence_chunks = int(fs / chunk * 1.5) # 1.5 seconds of silence to stop
    idle_timeout_chunks = int(fs / chunk * idle_timeout)
    silence_chunks = 0
    idle_chunks = 0
    recording = False
    
    max_chunks = int(fs / chunk * max_duration)
    
    for _ in range(max_chunks):
        data = stream.read(chunk, exception_on_overflow=False)
        rms = get_rms(data)
        
        if audio_state.is_speaking:
            if rms > 1500:  
                audio_state.trigger_barge_in()
            continue # Don't record while speaking unless it's a barge in
                
        if rms > silence_threshold:
            recording = True
            silence_chunks = 0
            idle_chunks = 0
            
        if recording:
            frames.append(data)
            if rms <= silence_threshold:
                silence_chunks += 1
            if silence_chunks > max_silence_chunks:
                break
        else:
            idle_chunks += 1
            if idle_chunks > idle_timeout_chunks:
                break
                
    stream.stop_stream()
    stream.close()
    p.terminate()

    if frames:
        with wave.open(filename, 'wb') as wf:
            wf.setnchannels(channels)
            wf.setsampwidth(p.get_sample_size(sample_format))
            wf.setframerate(fs)
            wf.writeframes(b''.join(frames))
        return True
    return False

def transcribe_sync(filename: str) -> str:
    if not model:
        return ""
    segments, _ = model.transcribe(filename, beam_size=5)
    return " ".join([segment.text for segment in segments]).strip()

async def listen_for_input(wake_word_mode: bool = False) -> str:
    if wake_word_mode:
        logger.info("Listening for wake word 'JARVIS'...")
    else:
        logger.info("Listening for command...")
        
    temp_file = tempfile.mktemp(suffix=".wav")
    try:
        while True:
            # If in wake word mode, idle timeout is long so we just keep restarting.
            # If in command mode, idle timeout is 5s, we return "" if user is silent.
            has_speech = await asyncio.to_thread(record_utterance_to_file, temp_file, 15, 5)
            if not has_speech:
                if wake_word_mode:
                    continue
                else:
                    logger.info("Command timeout. Going back to sleep.")
                    return ""
                
            text = await asyncio.get_running_loop().run_in_executor(executor, transcribe_sync, temp_file)
            if not text:
                if not wake_word_mode:
                    return ""
                continue
                
            text_lower = text.lower().strip()
            # In wake word mode, check if the transcription contains jarvis.
            # If so, return the full text so the brain can process it if the user said "Jarvis, do X".
            if wake_word_mode:
                if "jarvis" in text_lower:
                    logger.info(f"Wake word detected in: {text}")
                    return text
                else:
                    # Ignore background speech that isn't the wake word
                    continue
            else:
                logger.info(f"Transcribed: {text}")
                return text
                
    except Exception as e:
        logger.error(f"STT Error: {e}")
        return ""
    finally:
        if os.path.exists(temp_file):
            try:
                os.remove(temp_file)
            except OSError:
                pass
